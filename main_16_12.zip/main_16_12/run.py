from forms import LoginForm
from flask import Flask, render_template, request
from main import compute

app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def index():
	form = LoginForm(request.form)
	if request.method == 'POST' and form.validate():
		result = compute(form.Sepal_Length.data, form.Sepal_Width.data,
form.Petal_Length.data, form.Petal_Width.data)
	else:
		result = None	
	return render_template('login.html',form=form, result=result)

if __name__ == '__main__':
    app.run(host='0.0.0.0')


